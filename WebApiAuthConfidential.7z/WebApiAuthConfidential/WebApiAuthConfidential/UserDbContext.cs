﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using WebApiAuthConfidential.Models;

namespace WebApiAuthConfidential
{
    public class UserDbContext : IdentityDbContext<IdentityUser>
    {
        public DbSet<Credentials> Credentials { get; set; }

        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {
        }
    }
}
