﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using WebApiAuthConfidential.Models;
using WebApiAuthConfidential.Utils;

namespace WebApiAuthConfidential.Controllers
{
    [Produces("application/json")]
    [Route("api/Authenticate")]
    public class AuthenticateController : Controller
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly SignInManager<IdentityUser> signInManager;
        private readonly UserDbContext userDbContext;

        public AuthenticateController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager, UserDbContext userDbContext)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.userDbContext = userDbContext;
        }

        [HttpPost]
        public async Task<IActionResult> Authenticate([FromBody] Credentials credentials)
        {
            var user = new IdentityUser { UserName = credentials.Email, Email = credentials.Email };

            var result = await userManager.CreateAsync(user, credentials.Password);

            if (!result.Succeeded)
            {
                return BadRequest(false);
            }

            await signInManager.SignInAsync(user, isPersistent: false);

            string token = TokenUtils.CreateToken(user);

            credentials.Token = token;

            this.userDbContext.Credentials.Add(credentials);
            await this.userDbContext.SaveChangesAsync();

            return Ok(true);
        }
    }
}