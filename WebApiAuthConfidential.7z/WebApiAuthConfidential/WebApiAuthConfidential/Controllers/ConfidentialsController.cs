﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using WebApiAuthConfidential.Utils;

namespace WebApiAuthConfidential.Controllers
{
    [Produces("application/json")]
    [Route("api/Confidentials")]
    public class ConfidentialsController : Controller
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly SignInManager<IdentityUser> signInManager;
        private readonly UserDbContext userDbContext;

        public ConfidentialsController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager, UserDbContext userDbContext)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.userDbContext = userDbContext;
        }

        [HttpGet("{email}")]
        public async Task<IActionResult> Confidentials([FromRoute] string email)
        {
            var credentials = this.userDbContext.Credentials.FirstOrDefault(p => p.Email.Equals(email));

            if (credentials == null)
            {
                return NotFound(false);
            }

            var result = await signInManager. PasswordSignInAsync(credentials.Email, credentials.Password, false, false);

            if (!result.Succeeded)
            {
                return BadRequest(false);
            }

            var user = await userManager.FindByEmailAsync(email);
            string token = TokenUtils.CreateToken(user);

            if (token == credentials.Token)
            {
                return Ok(true);
            }
            else
            {
                return BadRequest(false);
            }
        }
    }
}