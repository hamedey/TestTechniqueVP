﻿using System.Net;
using System.Net.Http;
using System.Text;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WebApiAuthConfidential.Tests
{
    [TestClass]
    public class AuthConfidentialsIntegrationTests
    {
        private readonly HttpClient client;

        public AuthConfidentialsIntegrationTests()
        {
            var server = new TestServer(new WebHostBuilder().UseStartup<Startup>());
            this.client = server.CreateClient();
        }

        [TestMethod]
        public void TestAuthenticate()
        {
            //Arrange
            var request = new HttpRequestMessage(new HttpMethod("POST"), "/api/Authenticate");
            request.Content = new StringContent("{\"email\":\"myemail@gmail.com\",\"password\":\"Azerty123!\"}", Encoding.UTF8, "application/json");

            //Act
            var response = this.client.SendAsync(request).Result;

            //Assert
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
        }

        [TestMethod]
        [DataRow("myemail@gmail.com")]
        public void TestConfidentials(string email)
        {
            //Arrange
            var postRequest = new HttpRequestMessage(new HttpMethod("POST"), "/api/Authenticate");
            postRequest.Content = new StringContent("{\"email\":\"myemail@gmail.com\",\"password\":\"Azerty123!\"}", Encoding.UTF8, "application/json");

            var getRequest = new HttpRequestMessage(new HttpMethod("GET"), $"/api/Confidentials/{email}");

            //Act
            var postResponse = this.client.SendAsync(postRequest).Result;
            var getResponse = this.client.SendAsync(getRequest).Result;

            //Assert
            Assert.AreEqual(HttpStatusCode.OK, getResponse.StatusCode);
        }
    }
}
